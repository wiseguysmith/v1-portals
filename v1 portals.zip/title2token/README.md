# Title2Token — Admin Portal v1

Real estate asset tokenization platform. This repo contains the full UI design system and screen specifications for the **admin portal**, the first of six portals in the v1 build.

---

## Project overview

Title2Token is a multi-portal platform for tokenizing real estate assets. v1 ships the following:

| Component | Description |
|---|---|
| Admin portal | Platform control, deal oversight, user management |
| Developer / asset owner portal | Submit and manage tokenized assets |
| Broker portal | Deal flow and client management |
| Issuer portal | Token issuance and compliance |
| Legal partner portal | Document review, sign-off, diligence |
| Backend partner portal | Ops, custodian and registry |
| Native mobile app | Tasks, messages, approvals, push notifications |
| DocConnect integration | Document signing and audit trail |
| Workflow engine | Reusable checklists, deal stages, task routing |
| Provider-agnostic handoff | Abstracted integrations for chain, custodian, transfer agent |

---

## Design system

**Colors**
```
Background:   #f5f3ef  (off-white)
Text:         #1a1a18  (near-black)
Gold accent:  #b8952a  (primary action, active states)
Gold light:   #f5f0e6  (gold tint, active backgrounds)
Border:       #e0ddd8
Muted text:   #aaa8a2
Faint:        #ccc9c2
```

**Typography**
```
UI font:    DM Sans (300, 400, 500)
Mono font:  DM Mono (400, 500) — used for values, timestamps, codes
```

**Principles**
- Off-white base, no heavy card fills — content sits on the background directly
- Gold used sparingly — active nav, key values, primary actions only
- 1px borders throughout, generous whitespace
- Minimal use of color as status signal — dot + label, never background flooding

---

## Admin portal — screen inventory

| Screen | File | Status |
|---|---|---|
| Dashboard | `admin/screens/dashboard.html` | ✅ Complete |
| Deal detail | `admin/screens/deal-detail.html` | ✅ Complete |
| Workflow builder | `admin/screens/workflow-builder.html` | ✅ Complete |
| User management | `admin/screens/user-management.html` | ✅ Complete |
| Audit log | `admin/screens/audit-log.html` | ✅ Complete |
| Settings | `admin/screens/settings.html` | ✅ Complete |
| Pipeline list | `admin/screens/pipeline-list.html` | ✅ Complete |

---

## Architecture notes

### Workflow engine
The workflow engine is the strategic core. Every portal feeds into it.
- Deal stages are configurable per template (Commercial, Residential, Industrial)
- Each stage contains ordered steps with: `role`, `required` boolean, `order` integer
- Required steps block stage progression; optional steps can be skipped
- Template changes version-lock against active deals — prompt admin before applying

### Role and permission system
Five portal roles, each scoped to specific deal data:
- `developer` — submit and track their own assets
- `broker` — view and refer deals
- `issuer` — token issuance stage only
- `legal` — document review and sign-off
- `backend` — custodian and registry ops

Access levels: `full` (act on deals) | `view` (read-only)

Admin configures roles dynamically — no code deploy required.

### DocConnect integration
- Adapter pattern — swap signing provider without rewriting business logic
- Envelope status webhooks update deal checklist in real time
- Audit trail stored per-envelope, linked to deal ID

### Provider-agnostic handoff
- Chain provider, custodian, KYC/AML all behind adapter interfaces
- Credentials managed in Settings > Integrations
- Swap providers by reconnecting — business logic unaffected

### API design
- Single `/admin/stats` endpoint powers the dashboard metrics row
- Audit log uses cursor-based pagination — never load full history
- Status (active/away/offline) derived from `last_seen` timestamp — not manual
- Invites auto-expire after configurable window (default 7 days)

### Mobile app
- React Native (or equivalent), shares API layer with portals
- Additions: push notification handler, approval-focused UI
- No separate data layer — same backend

---

## Repo structure

```
title2token/
├── README.md
├── docs/
│   ├── architecture.md
│   └── nda.docx
├── public/
│   └── design-tokens.css
├── admin/
│   ├── screens/
│   │   ├── dashboard.html
│   │   ├── deal-detail.html
│   │   ├── workflow-builder.html
│   │   ├── user-management.html
│   │   ├── audit-log.html
│   │   ├── settings.html
│   │   └── pipeline-list.html
│   ├── components/
│   │   ├── nav.html
│   │   ├── topbar.html
│   │   └── shared.css
│   └── styles/
│       └── admin.css
└── .gitignore
```

---

## Getting started (developer)

1. Clone the repo
2. Open any `admin/screens/*.html` file directly in a browser — no build step required for the design reference
3. Design tokens are in `public/design-tokens.css` — import into your component library
4. Review `docs/architecture.md` for backend decisions before writing any data models

---

## Portals remaining for v1 (not yet designed)

- [ ] Developer / asset owner portal
- [ ] Broker portal
- [ ] Issuer portal
- [ ] Legal partner portal
- [ ] Backend partner portal
- [ ] Native mobile app screens

---

## Status

`Admin portal — design complete ✅`  
`Other portals — pending`  
`Backend — not started`  
`Mobile — not started`
